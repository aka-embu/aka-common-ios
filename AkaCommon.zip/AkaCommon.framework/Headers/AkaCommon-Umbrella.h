//
//  AkaCommon-Umbrella.h
//  AkaCommon
//
//  Created by Brian Salomon on 4/8/19.
//  Copyright © 2019 Akamai Technologies, Inc. All rights reserved.
//

#ifndef AkaCommon_Umbrella_h
#define AkaCommon_Umbrella_h

// Public includes in AkaCommon.framework
#import "AkaCommon.h"

#endif /* AkaCommon_Umbrella_h */
